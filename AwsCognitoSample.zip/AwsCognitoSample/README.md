# CognitoExample

Example Node app with Amazon Cognito and S3.

As per http://blog.backspace.academy/2015/03/using-cognito-with-nodejs-part-2.html.

    # Copy `.env.example` to `.env` and edit.
    npm install
    nodemon

Open on http://localhost:8080.
