require('dotenv').config();
var express = require('express');
var router = express.Router();
var AWS = require('aws-sdk');
//var AWSCognito = require('amazon-cognito-identity-js');
var AWSCognito = require('amazon-cognito-identity-js-node');

var AWS_ACCOUNT_ID = process.env.AWS_ACCOUNT_ID;
var AWS_REGION = process.env.AWS_REGION;
var USER_POOL_ID = process.env.USER_POOL_ID;
var USER_POOL_ARN = process.env.USER_POOL_ARN;
var CLIENT_ID = process.env.CLIENT_ID;
var COGNITO_IDENTITY_POOL_ID = process.env.COGNITO_IDENTITY_POOL_ID;;
var COGNITO_IDENTITY_ID, COGNITO_SYNC_TOKEN, AWS_TEMP_CREDENTIALS;
var cognitosync;
var IAM_ROLE_ARN = process.env.IAM_ROLE_ARN;
var COGNITO_SYNC_COUNT;
var COGNITO_DATASET_NAME = 'TEST_DATASET';

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.render("login");
});
router.post('/signinss', function(req, res, next) {
     var authenticationData = {
          Username: req.body.username,
          Password: req.body.password,
     };
     var authenticationDetails = new AWS.AuthenticationDetails(authenticationData);
     var poolData = {
          UserPoolId: USER_POOL_ID,
          ClientId: CLIENT_ID
     };


     var userPool = new AWS.CognitoUserPool(poolData);
     var userData = {
          Username: req.body.username,
          Pool: userPool
     };

     //Trying to use Promises
     var cognitoUser = new AWS.CognitoUser(userData);
     
	 return cognitoUser.authenticateUser(authenticationDetails)
          .then(function(result) {
               console.log('access token + ' + result.getAccessToken().getJwtToken());
               //Use the idToken for Logins Map when Federating User Pools with Cognito Identity or when passing through an Authorization Header to an API Gateway Authorizer
               console.log('idToken + ' + result.idToken.jwtToken);
               return result;
          })
          .catch(function(err) {
               console.log(err);
               return err;
          });

     //Trying to use Object Listeners
     var request = cognitoUser.authenticateUser(authenticationDetails).promise();
     return request.on('success', function(response) {
          console.log('access token + ' + response.getAccessToken().getJwtToken());
          //Use the idToken for Logins Map when Federating User Pools with Cognito Identity or when passing through an Authorization Header to an API Gateway Authorizer
          console.log('idToken + ' + response.idToken.jwtToken);
          return response;
     }).
     on('failure', function(err) {
          console.log("Error!");
          return err;
     }).send();

});

router.post('/signin', function(req, res, next) {
	var username = req.body.username;
    var pwd = req.body.password;
	
    AWSCognito.config.region = AWS_REGION;
    var poolData = {
      UserPoolId : USER_POOL_ID,
      ClientId : CLIENT_ID
    };
    var userPool = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
    var authenticationData = {
      Username : username,
      Password : pwd,
    };
    var authenticationDetails = new AWSCognito.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);
    var userData = {
      Username : username,
      Pool : userPool
    };
    var cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);
    
	cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: function (result) {
        console.log('access token + ' + result.getAccessToken().getJwtToken());
        /*Use the idToken for Logins Map when Federating User Pools with Cognito Identity or when passing through an Authorization Header to an API Gateway Authorizer*/
        console.log('idToken + ' + result.idToken.jwtToken);
        userPoolToken = result.getIdToken().getJwtToken();
        console.log("userPoolToken = "+ userPoolToken);
        //We can take AWS.config.credentials from the session object for linking.
        AWSCognito.config.credentials = new AWSCognito.CognitoIdentityCredentials({
          IdentityPoolId: global_identityPoolId,
          Logins: {}
        });
        AWSCognito.config.credentials.params.Logins[USER_POOL_ARN] = result.idToken.jwtToken;
        AWSCognito.config.credentials.get((error) => {
          if (error) {
			alert('uppp'+err);  
            console.log("## credentials.get: " + error);
            return res.status(error.statusCode).send({ success: false, message: error.message });
          }
          else{
			alert('sdsds'+err);  
            console.log(AWSCognito.config.credentials.identityId);
            return res.status(200).send({ 
              success: true, 
              message: 'Logged in', 
              user: { 
                id: AWSCognito.config.credentials.identityId
              }
            });
          }
        }); 
      },
      onFailure: function(err) {
        console.error(err);
		alert(err);
        return res.status(err.statusCode).send({ success: false, message: err.message, error : err});
      }
    });
});
router.post('/signin_oldd', function(req, res, next) {
	var username = req.body.username;
    var pwd = req.body.password;
	
	AWS.config.region = process.env.AWS_REGION;
    
	var authenticationData = {
        Username : username,
        Password : pwd,
    };
	var authenticationDetails = new AWS.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);
    var poolData = { UserPoolId : 'us-east-1_wmUQa86c1',
        ClientId : '69jpgmaqa216ongaqb9986ft0r'
    };
	var userPool = new AWS.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
    var userData = {
        Username : username,
        Pool : userPool
    };
	var cognitoUser = new AWS.CognitoIdentityServiceProvider.CognitoUser(userData);
    cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: function (result) {
            console.log('access token + ' + result.getAccessToken().getJwtToken());
            /*Use the idToken for Logins Map when Federating User Pools with Cognito Identity or when passing through an Authorization Header to an API Gateway Authorizer*/
            console.log('idToken + ' + result.idToken.jwtToken);
        },

        onFailure: function(err) {
            console.log(err);
        },
		/* newPasswordRequired: function(userAttributes, requiredAttributes) {
            // User was signed up by an admin and must provide new
            // password and required attributes, if any, to complete
            // authentication.

            // the api doesn't accept this field back
            //delete userAttributes.email_verified;

            // Get these details and call
            cognitoUser.completeNewPasswordChallenge('12345678', userAttributes);
        } */

    });
});
router.post('/signin_old', function(req, res, next) {
    var username = req.body.username;
    var pwd = req.body.password;
    console.log(username+'___'+pwd);

    AWS.config.region = process.env.AWS_REGION;
    var poolData = {
      UserPoolId : process.env.USER_POOL_ID,
      ClientId : process.env.CLIENT_ID
    };
    var userPool = new AWS.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
    var authenticationData = {
      Username : username,
      Password : pwd,
    };
    var authenticationDetails = new AWS.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);
    var userData = {
      Username : username,
      Pool : userPool
    };
    var cognitoUser = new AWS.CognitoIdentityServiceProvider.CognitoUser(userData);

    cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: function (result) {
        console.log('access token + ' + result.getAccessToken().getJwtToken());
        /*Use the idToken for Logins Map when Federating User Pools with Cognito Identity or when passing through an Authorization Header to an API Gateway Authorizer*/
        console.log('idToken + ' + result.idToken.jwtToken);
        userPoolToken = result.getIdToken().getJwtToken();
        console.log("userPoolToken = "+ userPoolToken);
        //We can take AWS.config.credentials from the session object for linking.
        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
          IdentityPoolId: global_identityPoolId,
          Logins: {}
        });
        AWS.config.credentials.params.Logins[USER_POOL_ARN] = result.idToken.jwtToken;
        AWS.config.credentials.get((error) => {
          if (error) {
            //if (err.code == 'UserNotConfirmedException'){
				// Not confirmed
			//} else if (err.code == 'PasswordResetRequiredException'){
				// Reset Password Required
			//} else if (err.code == 'NotAuthorizedException'){
				// Not Authorised (Incorrect Password)
			//} else if (err.code == 'ResourceNotFoundException'){
				// User Not found
			//} else {
				// Unknown
			//} 
			
			console.log("## credentials.get: " + error);
            return res.status(error.statusCode).send({ success: false, message: error.message });
          }
          else{
            console.log(AWS.config.credentials.identityId);
            return res.status(200).send({ 
              success: true, 
              message: 'Logged in', 
              user: { 
                id: AWS.config.credentials.identityId
              }
            });
          }
        }); 
      },
      onFailure: function(err) {
        console.error(err);
        return res.status(err.statusCode).send({ success: false, message: err.message, error : err});
      },
		newPasswordRequired: function(userAttributes, requiredAttributes) {
            // User was signed up by an admin and must provide new
            // password and required attributes, if any, to complete
            // authentication.

            // the api doesn't accept this field back
            //delete userAttributes.email_verified;

            // Get these details and call
            //cognitoUser.completeNewPasswordChallenge(pwd, userAttributes);
        }
    });
});
module.exports = router;
