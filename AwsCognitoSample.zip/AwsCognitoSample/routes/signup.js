require('dotenv').config();
var express = require('express');
var router = express.Router();
var AWS = require('aws-sdk');
var AWSCognito = require('amazon-cognito-identity-js');

var AWS_ACCOUNT_ID = process.env.AWS_ACCOUNT_ID;
var AWS_REGION = process.env.AWS_REGION;
var USER_POOL_ID = process.env.USER_POOL_ID;
var CLIENT_ID = process.env.CLIENT_ID;
var COGNITO_IDENTITY_POOL_ID = process.env.COGNITO_IDENTITY_POOL_ID;;
var COGNITO_IDENTITY_ID, COGNITO_SYNC_TOKEN, AWS_TEMP_CREDENTIALS;
var cognitosync;
var IAM_ROLE_ARN = process.env.IAM_ROLE_ARN;
var COGNITO_SYNC_COUNT;
var COGNITO_DATASET_NAME = 'TEST_DATASET';

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.render("signup");
});

router.post('/adduser', function(req, res, next) {
    var email = req.body.email;
    var username = req.body.username;
    var phone_number = '+91'+req.body.phone;
    var pwd = req.body.password;
    console.log(email+'___'+username+'___'+phone_number+'___'+pwd);

    AWS.config.region = process.env.AWS_REGION;
	AWS.config.credentials = new AWS.CognitoIdentityCredentials({
		IdentityPoolId: process.env.COGNITO_IDENTITY_POOL_ID,
	});
    var poolData = {
		UserPoolId : process.env.USER_POOL_ID,
		ClientId : process.env.CLIENT_ID
    };
    var userPool = new AWS.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
    var attributeList = [];
	
	var dataEmail = {
		Name : 'email',
		Value : email
	};
	var dataPhoneNumber = {
		Name : 'phone_number',
		Value : phone_number
	};
	var attributeEmail = new AWS.CognitoIdentityServiceProvider.CognitoUserAttribute(dataEmail);
	var attributePhoneNumber = new AWS.CognitoIdentityServiceProvider.CognitoUserAttribute(dataPhoneNumber);
	
	attributeList.push(attributeEmail);
	attributeList.push(attributePhoneNumber);
	
	userPool.signUp(username, phone_number, attributeList, null, function(err, result){
	if (err) {
		console.error(err);
        return res.status(err.statusCode).send({ success: false, message: err.message, error : err});
	}else{
		//localStorage.setItem('token', JSON.stringify(result.idToken.jwtToken));
		cognitoUser = result.user;
		return res.status(200).send({ 
		  success: true, 
		  message: 'Success', 
		  user: { 
			name:cognitoUser.getUsername()
		  }
		});
		
	}
});
});
module.exports = router;
