require('dotenv').config();
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: '..' });
});


// from example
var passport = require('passport');
var TwitterStrategy = require('passport-twitter').Strategy;
var AWS = require('aws-sdk');
var colors = require('colors');

var AWS_ACCOUNT_ID = process.env.AWS_ACCOUNT_ID;
var AWS_REGION = process.env.AWS_REGION;
var COGNITO_IDENTITY_POOL_ID = process.env.COGNITO_IDENTITY_POOL_ID;;
var COGNITO_IDENTITY_ID, COGNITO_SYNC_TOKEN, AWS_TEMP_CREDENTIALS;
var cognitosync;
var IAM_ROLE_ARN = process.env.IAM_ROLE_ARN;
var COGNITO_SYNC_COUNT;
var COGNITO_DATASET_NAME = process.env.COGNITO_DATASET_NAME;

// test app
var TWITTER_TOKEN;
var TWITTER_USER_ID;
var TWITTER_USER_Name;
var TWITTER_USER = {
  id: '',
  displayName:''
};
var userLoggedIn = false;

router.use(passport.initialize());
router.use(passport.session());

passport.use(new TwitterStrategy({
  consumerKey: process.env.TWITTER_APP_ID,
  consumerSecret: process.env.TWITTER_APP_SECRET,
  callbackURL: 'http://127.0.0.1:8080/twitterlogin/auth/twitter/callback'
}, function(token, tokenSecret, profile, done) {
  process.nextTick(function() {
	TWITTER_TOKEN = token+';'+tokenSecret;  
    TWITTER_USER = profile._json;
    TWITTER_USER_ID = TWITTER_USER.id;
	//console.log('PROFILE: '.yellow + JSON.stringify(profile));
    TWITTER_USER_Name = TWITTER_USER.displayName;
	userLoggedIn = true;
    done(null, profile);
  });
}));

passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(obj, done) {
  done(null, obj);
});
// /from example

router.use(require('morgan')('combined'));
router.use(require('cookie-parser')());
router.use(require('body-parser').urlencoded({ extended: true }));
router.use(require('express-session')({ secret: 'keyboard cat', resave: true, saveUninitialized: true ,cookie: { secure: false }}));

/* GET twitter page. */
router.get('/auth/twitter', passport.authenticate('twitter'));

/* GET twitter callback page. */
router.get('/auth/twitter/callback', passport.authenticate('twitter', {
  successRedirect: '/twitterlogin/successtw',
  failureRedirect: '/error'
}));

/* GET Facebook success page. */
router.get('/successtw', function(req, res, next) {
  console.log('TWITTER_TOKEN:'.green + TWITTER_TOKEN);
  getCognitoID();
  res.send('Logged in as ' + TWITTER_USER_Name + ' (id:' + TWITTER_USER_ID + ').');
});

router.route('/sync')
  .put(function(req, res) {
    res.json({ message: 'Sync Put Started' });
  })
  .get(function(req, res) {

  });

/* GET twitter error page. */
router.get('/error', function(req, res, next) {
  res.send("Unable to access TWITTER servers. Please check internet connection or try again later.");
});

function getCognitoID(){
  // The parameters required to intialize the Cognito Credentials object.
  var params = {
    AccountId: AWS_ACCOUNT_ID, // required
    RoleArn: IAM_ROLE_ARN,  // required
    IdentityPoolId: COGNITO_IDENTITY_POOL_ID, // required
    Logins: {
      'api.twitter.com': TWITTER_TOKEN
    }
  };
  // set the Amazon Cognito region
  AWS.config.region = AWS_REGION;
  // initialize the Credentials object with our parameters
  AWS.config.credentials = new AWS.CognitoIdentityCredentials(params);

  // We can set the get method of the Credentials object to retrieve
  // the unique identifier for the end user (identityId) once the provider
  // has refreshed itself
  AWS.config.credentials.get(function(err) {
    if (err) console.log("credentials.get: ".red + err, err.stack); // an error occurred
      else{
        //AWS_TEMP_CREDENTIALS = AWS.config.credentials.data.Credentials;
        AWS_TEMP_CREDENTIALS = AWS.config.credentials;
        COGNITO_IDENTITY_ID = AWS.config.credentials.identityId;
        console.log("Cognito Identity Id: ".green + COGNITO_IDENTITY_ID);
        getCognitoSynToken();
      }
  });
}

function getCognitoSynToken(){
  // Other AWS SDKs will automatically use the Cognito Credentials provider
  // configured in the JavaScript SDK.
  cognitosync = new AWS.CognitoSync();
  cognitosync.listRecords({
    DatasetName: COGNITO_DATASET_NAME, // required
    IdentityId: COGNITO_IDENTITY_ID,  // required
    IdentityPoolId: COGNITO_IDENTITY_POOL_ID  // required
  }, function(err, data) {
    if (err) console.log("listRecords: ".red + err, err.stack); // an error occurred
      else {
        console.log("listRecords: ".green + JSON.stringify(data));
        COGNITO_SYNC_TOKEN = data.SyncSessionToken;
        COGNITO_SYNC_COUNT = data.DatasetSyncCount;
        console.log("SyncSessionToken: ".green + COGNITO_SYNC_TOKEN);           // successful response
        console.log("DatasetSyncCount: ".green + COGNITO_SYNC_COUNT);
        addRecord();
      }
  });
}

function addRecord(){
  var params = {
    DatasetName: COGNITO_DATASET_NAME, // required
    IdentityId: COGNITO_IDENTITY_ID, // required
    IdentityPoolId: COGNITO_IDENTITY_POOL_ID, // required
    SyncSessionToken: COGNITO_SYNC_TOKEN, // required
    RecordPatches: [
      {
        Key: 'USER_ID', // required
        Op: 'replace', // required
        SyncCount: COGNITO_SYNC_COUNT, // required
        //DeviceLastModifiedDate: new Date(),
        Value: TWITTER_USER_ID.toString()
      }
    ]
  };
  console.log("UserID: ".cyan + TWITTER_USER_ID.toString());
  cognitosync.updateRecords(params, function(err, data) {
    if (err) console.log("updateRecords: ".red + err, err.stack); // an error occurred
    else{
      console.log("Value: ".green + JSON.stringify(data));           // successful response
      //createS3();
    }
  });
}

function createS3(){
  var bucket = new AWS.S3({
    params: {
      Bucket: 'backspace-cognito-test'
    }
  });
  //Object key will be facebook-USERID#/FILE_NAME
  console.log('COGNITO_IDENTITY_ID: '.cyan + COGNITO_IDENTITY_ID);
  var objKey = COGNITO_IDENTITY_ID + '/test2.txt';
  var params = {
      Key: objKey,
      ContentType: 'text/plain',
      Body: "Hello!",
      ACL: 'public-read'
  };
  bucket.putObject(params, function (err, data) {
    if (err) {
        console.log('putObject: '.red + err);
    } else {
        console.log("Successfully uploaded data to your S3 bucket");
    }
  });
}

module.exports = router;